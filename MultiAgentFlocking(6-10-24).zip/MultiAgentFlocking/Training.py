import numpy as np
import torch as th
from Parameters import *
from stable_baselines3 import PPO
from main import FlockingEnv, CustomMultiAgentPolicy
from Callbacks import TQDMProgressCallback, LossCallback
import os

if os.path.exists(Results["Rewards"]):
    os.remove(Results["Rewards"])
    print(f"File {Results['Rewards']} has been deleted.")

if os.path.exists("training_rewards.json"):
    os.remove("training_rewards.json")
    print(f"File training_rewards has been deleted.")    

def seed_everything(seed):
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    th.manual_seed(seed)
    th.cuda.manual_seed(seed)
    th.backends.cudnn.deterministic = True
    env.seed(seed)
    env.action_space.seed(seed)


# Initialize environment and policy
env = FlockingEnv()
seed_everything(SimulationVariables["Seed"])
loss_callback = LossCallback()

# Initialize PPO model with custom multi-agent policy
model = PPO(CustomMultiAgentPolicy, env, tensorboard_log="./ppo_Agents_tensorboard/", verbose=1)
model.set_random_seed(SimulationVariables["ModelSeed"])
progress_callback = TQDMProgressCallback(total_timesteps=SimulationVariables["LearningTimeSteps"])

# Custom training loop parameters
n_steps = model.n_steps
total_timesteps = SimulationVariables["LearningTimeSteps"]
timesteps_so_far = 0

# Set up storage for observations, rewards, etc.
obs = env.reset()
model.policy.set_training_mode(True)

while timesteps_so_far < total_timesteps:
    # Collect rollout (n_steps steps of experience)
    actions, values, log_probs = [], [], []
    rewards, dones = [], []
    
    for _ in range(n_steps):
        agent_actions = []
        agent_values = []
        agent_log_probs = []

        for agent_id, agent_obs in enumerate(obs):
            # Forward pass for each agent (passing in agent-specific actor)
            action_logits = model.policy.forward(agent_obs, agent_id)
            action, value, log_prob = model.policy.action_value_logprob(action_logits)

            agent_actions.append(action)
            agent_values.append(value)
            agent_log_probs.append(log_prob)
        
        actions.append(agent_actions)
        values.append(agent_values)
        log_probs.append(agent_log_probs)
        
        # Take the actions in the environment
        new_obs, reward, done, info = env.step(agent_actions)
        
        rewards.append(reward)
        dones.append(done)
        obs = new_obs
        
        timesteps_so_far += 1
        
        # Callback for progress or loss
        if progress_callback is not None:
            progress_callback.on_step()
        if loss_callback is not None:
            loss_callback.on_step()
            
        if timesteps_so_far >= total_timesteps:
            break
    
    # After collecting experience, update the policy for all agents
    model.train_on_rollout(actions, rewards, dones, values, log_probs)
    
    # Perform any other logging or callbacks at the end of the iteration
    if progress_callback is not None:
        progress_callback.on_rollout_end()
    if loss_callback is not None:
        loss_callback.on_rollout_end()

# Save the model after training
model.save(rf"{Files['Flocking']}\\Models\\FlockingCombinedNew")


